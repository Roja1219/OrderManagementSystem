import { Component, OnInit } from '@angular/core';
import { IProduct } from './products.model';
import { ProductsService } from './products.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

    title : string = 'Product List';
    showTable: boolean = true;
    showImage: boolean = false;
    userSearch: string ;
    imageWidth:number =100;
    serverstatus:string='offline';
    
    constructor(private productsservice: ProductsService ){ }

    product: IProduct[] ;
    
    ngOnInit(){
        this.product = this.productsservice.getProducts(); 
    }


    toggleImage() : void {
        this.showImage = !this.showImage;
    }

    onDataRecive(message: string): void {
        this.title = ' Product List  ' + message;
    }
}