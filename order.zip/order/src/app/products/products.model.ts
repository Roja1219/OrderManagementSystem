export interface IProduct {
OrderNumber: number,
OrderDueDate:string,
CustomerBuyerName:string,
CustomerAddress:string,
CustomerPhone:string,
OrderTotal:number,
}