import { Component , Injectable } from '@angular/core';
import { ProductsComponent } from './products.component';
import { IProduct } from './products.model';

@Injectable()

export class ProductsService {

    getProducts(): IProduct[] {
        return [
            {
                OrderNumber: 789,
                OrderDueDate:'October 15, 2019',
                CustomerBuyerName:'GHI',
                CustomerAddress:'Mumbai',
                CustomerPhone:'9876543210',
                OrderTotal:500,
            },
            {
                OrderNumber: 123,
                OrderDueDate:'May 21, 2019',
                CustomerBuyerName:'ABC',
                CustomerAddress:'Hyderabad',
                CustomerPhone:'9876543210',
                OrderTotal:100,
            },          
            {
                OrderNumber: 456,
                OrderDueDate:'May 15, 2019',
                CustomerBuyerName:'DEF',
                CustomerAddress:'Chennai',
                CustomerPhone:'9876543210',
                OrderTotal:200,
            },           
            {
                OrderNumber: 789,
                OrderDueDate:'October 15, 2019',
                CustomerBuyerName:'GHI',
                CustomerAddress:'Mumbai',
                CustomerPhone:'9876543210',
                OrderTotal:500,
            }
    
        ];
    }   
}